﻿
Public Module ArithmeticOperators

    Public Sub Main()

        Console.WriteLine("Adding 2 + 2")
        Console.WriteLine(2 + 2)

        Console.ReadLine()

        Console.WriteLine("Subtracting 6 - 4")
        Console.WriteLine(6 - 4)

        Console.ReadLine()

        Console.WriteLine("3 x 4 is")
        Console.WriteLine(3 * 4)

        Console.ReadLine()

        Console.WriteLine("Floating Point Division")
        Console.WriteLine("20 / 6 is")
        Console.WriteLine(20 / 6)

        Console.ReadLine()

        Console.WriteLine("Integer Division")
        Console.WriteLine("20 \ 6 is")
        Console.WriteLine(20 \ 6)

        Console.ReadLine()

        Console.WriteLine("Modulus gives only the remainder")
        Console.WriteLine("20 Mod 6 is")
        Console.WriteLine(20 Mod 6)

        Console.ReadLine()

        Console.WriteLine("5^2 is")
        Console.WriteLine(5 ^ 2)

        Console.ReadLine()

    End Sub

End Module



