﻿Public Class AnotherForm

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        FridayForm.Show()
        Me.Hide()
    End Sub

End Class