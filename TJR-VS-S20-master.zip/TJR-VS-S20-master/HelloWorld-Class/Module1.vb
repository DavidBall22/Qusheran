﻿'Tim Rossiter
'RCET0265
'Spring 2020
'Hello World

Module Module1

    Sub Main()
        Console.WriteLine("Hello, World!")
        Console.ReadLine()
    End Sub

End Module
