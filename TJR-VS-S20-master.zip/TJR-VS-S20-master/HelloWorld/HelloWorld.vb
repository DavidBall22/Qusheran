﻿Imports System

Module HelloWorld

    Sub Main()
        Console.WriteLine("Hello World!")
        Console.ReadLine()
    End Sub

End Module
