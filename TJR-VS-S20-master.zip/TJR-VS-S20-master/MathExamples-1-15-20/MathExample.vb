﻿'Tim Rossiter
'RCET0265
'Spring 2020
'Math Operators


Module MathExample

    Sub Main()

        'Addition operator
        Console.WriteLine("2 + 2")
        Console.WriteLine(2 + 2)
        Console.ReadLine()

        'Subtraction operator
        Console.WriteLine("4 - 2")
        Console.WriteLine(4 - 2)
        Console.ReadLine()

        'Multipy operator
        Console.WriteLine("2 * 2")
        Console.WriteLine(2 * 2)
        Console.ReadLine()

        'Division operator. Returns decimal
        Console.WriteLine("25 / 3")
        Console.WriteLine(25 / 3)
        Console.ReadLine()

        'Integer Division operator. Returns Integer. no remainder
        Console.WriteLine("25 \ 3")
        Console.WriteLine(25 \ 3)
        Console.ReadLine()

        'Modulus operator. Returns only remainder
        Console.WriteLine("25 Mod 3")
        Console.WriteLine(25 Mod 3)
        Console.ReadLine()

        'Exponant operator
        Console.WriteLine("2^8")
        Console.WriteLine(2 ^ 8)
        Console.ReadLine()

    End Sub

End Module
