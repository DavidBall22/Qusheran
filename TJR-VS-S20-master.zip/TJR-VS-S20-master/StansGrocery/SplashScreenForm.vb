﻿Public Class SplashScreenForm
    Private Sub LeaveSplashScreenForm(sender As Object, e As EventArgs) Handles Me.Click, Me.KeyPress, SplashTimer.Tick
        Me.Hide()
        'StansGroceryForm.Show()



    End Sub

End Class