﻿Public Class StansGroceryForm
    Sub stuff()
        Dim junk$
        junk$ = My.Resources.


    End Sub
End Class
